document.getElementById('reservation-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Reservation confirmed!');
});
window.addEventListener('scroll', function() {
    const elements = document.querySelectorAll('.fade-in-element');
    elements.forEach(function(element) {
        if (isElementInViewport(element)) {
            element.classList.add('fade-in');
        }
    });
});

function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return rect.top >= 0 && rect.bottom <= window.innerHeight;
}
document.getElementById('order-form').addEventListener('submit', function(event) {
    event.preventDefault();

    // Get the form data
    const name = document.getElementById('name').value;
    const age = document.getElementById('age').value;
    const city = document.getElementById('city').value;
    const email = document.getElementById('email').value;

    // Simulate form submission (you can replace this with an actual email service later)
    console.log("Order Details:", name, age, city, email);

    // Show success message
    document.getElementById('success-message').style.display = 'block';

    // Optionally clear the form
    document.getElementById('order-form').reset();
});

